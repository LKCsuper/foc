/*
 * File: openloop_data.c
 *
 * Code generated for Simulink model 'openloop'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Thu Aug 31 16:59:18 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "openloop.h"

/* Constant parameters (default storage) */
const ConstP_openloop_T openloop_ConstP = {
  /* Expression: rep_seq_y
   * Referenced by: '<S1>/Look-Up Table1'
   */
  { 0.0, 360.0 },

  /* Expression: rep_seq_t - min(rep_seq_t)
   * Referenced by: '<S1>/Look-Up Table1'
   */
  { 0.0, 0.12 }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
