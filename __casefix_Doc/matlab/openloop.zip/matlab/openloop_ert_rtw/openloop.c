/*
 * File: openloop.c
 *
 * Code generated for Simulink model 'openloop'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Thu Aug 31 16:59:18 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "openloop.h"
#include "rtwtypes.h"
#include "openloop_private.h"
#include "rt_nonfinite.h"
#include <math.h>
#include <float.h>

/* External outputs (root outports fed by signals with default storage) */
ExtY_openloop_T openloop_Y;

/* Real-time model */
static RT_MODEL_openloop_T openloop_M_;
RT_MODEL_openloop_T *const openloop_M = &openloop_M_;
real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
                     uint32_T maxIndex)
{
  real_T frac;
  real_T yL_0d0;
  uint32_T iLeft;

  /* Column-major Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = (u0 - bp0[0U]) / (bp0[1U] - bp0[0U]);
  } else if (u0 < bp0[maxIndex]) {
    uint32_T bpIdx;
    uint32_T iRght;

    /* Binary Search */
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = (u0 - bp0[maxIndex - 1U]) / (bp0[maxIndex] - bp0[maxIndex - 1U]);
  }

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  yL_0d0 = table[iLeft];
  return (table[iLeft + 1U] - yL_0d0) * frac + yL_0d0;
}

real_T rt_remd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (rtIsInf(u1)) {
    y = u0;
  } else if ((u1 != 0.0) && (u1 != trunc(u1))) {
    real_T q;
    q = fabs(u0 / u1);
    if (!(fabs(q - floor(q + 0.5)) > DBL_EPSILON * q)) {
      y = 0.0 * u0;
    } else {
      y = fmod(u0, u1);
    }
  } else {
    y = fmod(u0, u1);
  }

  return y;
}

real32_T rt_remf_snf(real32_T u0, real32_T u1)
{
  real32_T y;
  if (rtIsNaNF(u0) || rtIsNaNF(u1) || rtIsInfF(u0)) {
    y = (rtNaNF);
  } else if (rtIsInfF(u1)) {
    y = u0;
  } else if ((u1 != 0.0F) && (u1 != truncf(u1))) {
    real32_T q;
    q = fabsf(u0 / u1);
    if (!(fabsf(q - floorf(q + 0.5F)) > FLT_EPSILON * q)) {
      y = 0.0F * u0;
    } else {
      y = fmodf(u0, u1);
    }
  } else {
    y = fmodf(u0, u1);
  }

  return y;
}

/* Model step function */
void openloop_step(void)
{
  real_T rtb_LookUpTable1;
  real32_T absx;
  real32_T b_absx;
  real32_T x;
  real32_T x_tmp;
  int8_T n;
  boolean_T tmp;
  boolean_T tmp_0;

  /* Lookup_n-D: '<S1>/Look-Up Table1' incorporates:
   *  Clock: '<S1>/Clock'
   *  Constant: '<S1>/Constant'
   *  Math: '<S1>/Math Function'
   */
  rtb_LookUpTable1 = look1_binlxpw(rt_remd_snf(openloop_M->Timing.t[0], 0.12),
    openloop_ConstP.LookUpTable1_bp01Data,
    openloop_ConstP.LookUpTable1_tableData, 1U);

  /* MATLAB Function: '<S2>/MATLAB Function' incorporates:
   *  Constant: '<Root>/Constant'
   *  Constant: '<Root>/Constant1'
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  MATLAB Function: '<S2>/MATLAB Function1'
   */
  tmp = rtIsInfF((real32_T)rtb_LookUpTable1);
  tmp_0 = rtIsNaNF((real32_T)rtb_LookUpTable1);
  if (tmp || tmp_0) {
    x = (rtNaNF);
    b_absx = (rtNaNF);
  } else {
    x_tmp = rt_remf_snf((real32_T)rtb_LookUpTable1, 360.0F);
    x = x_tmp;
    b_absx = fabsf(x_tmp);
    absx = b_absx;
    if (b_absx > 180.0F) {
      if (x_tmp > 0.0F) {
        x = x_tmp - 360.0F;
      } else {
        x = x_tmp + 360.0F;
      }

      absx = fabsf(x);
    }

    if (absx <= 45.0F) {
      x *= 0.0174532924F;
      n = 0;
    } else if (absx <= 135.0F) {
      if (x > 0.0F) {
        x = (x - 90.0F) * 0.0174532924F;
        n = 1;
      } else {
        x = (x + 90.0F) * 0.0174532924F;
        n = -1;
      }
    } else if (x > 0.0F) {
      x = (x - 180.0F) * 0.0174532924F;
      n = 2;
    } else {
      x = (x + 180.0F) * 0.0174532924F;
      n = -2;
    }

    switch (n) {
     case 0:
      x = sinf(x);
      break;

     case 1:
      x = cosf(x);
      break;

     case -1:
      x = -cosf(x);
      break;

     default:
      x = -sinf(x);
      break;
    }

    if (b_absx > 180.0F) {
      if (x_tmp > 0.0F) {
        x_tmp -= 360.0F;
      } else {
        x_tmp += 360.0F;
      }

      b_absx = fabsf(x_tmp);
    }

    if (b_absx <= 45.0F) {
      x_tmp *= 0.0174532924F;
      n = 0;
    } else if (b_absx <= 135.0F) {
      if (x_tmp > 0.0F) {
        x_tmp = (x_tmp - 90.0F) * 0.0174532924F;
        n = 1;
      } else {
        x_tmp = (x_tmp + 90.0F) * 0.0174532924F;
        n = -1;
      }
    } else if (x_tmp > 0.0F) {
      x_tmp = (x_tmp - 180.0F) * 0.0174532924F;
      n = 2;
    } else {
      x_tmp = (x_tmp + 180.0F) * 0.0174532924F;
      n = -2;
    }

    switch (n) {
     case 0:
      b_absx = cosf(x_tmp);
      break;

     case 1:
      b_absx = -sinf(x_tmp);
      break;

     case -1:
      b_absx = sinf(x_tmp);
      break;

     default:
      b_absx = -cosf(x_tmp);
      break;
    }
  }

  openloop_Y.Va = -24.0F * x + 0.0F * b_absx;

  /* End of MATLAB Function: '<S2>/MATLAB Function' */

  /* MATLAB Function: '<S2>/MATLAB Function1' incorporates:
   *  Constant: '<Root>/Constant'
   *  Constant: '<Root>/Constant1'
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   */
  if (tmp || tmp_0) {
    x = (rtNaNF);
    b_absx = (rtNaNF);
  } else {
    x = rt_remf_snf((real32_T)rtb_LookUpTable1, 360.0F);
    absx = fabsf(x);
    if (absx > 180.0F) {
      if (x > 0.0F) {
        x -= 360.0F;
      } else {
        x += 360.0F;
      }

      absx = fabsf(x);
    }

    if (absx <= 45.0F) {
      x *= 0.0174532924F;
      n = 0;
    } else if (absx <= 135.0F) {
      if (x > 0.0F) {
        x = (x - 90.0F) * 0.0174532924F;
        n = 1;
      } else {
        x = (x + 90.0F) * 0.0174532924F;
        n = -1;
      }
    } else if (x > 0.0F) {
      x = (x - 180.0F) * 0.0174532924F;
      n = 2;
    } else {
      x = (x + 180.0F) * 0.0174532924F;
      n = -2;
    }

    switch (n) {
     case 0:
      x = cosf(x);
      break;

     case 1:
      x = -sinf(x);
      break;

     case -1:
      x = sinf(x);
      break;

     default:
      x = -cosf(x);
      break;
    }

    x_tmp = rt_remf_snf((real32_T)rtb_LookUpTable1, 360.0F);
    b_absx = fabsf(x_tmp);
    if (b_absx > 180.0F) {
      if (x_tmp > 0.0F) {
        x_tmp -= 360.0F;
      } else {
        x_tmp += 360.0F;
      }

      b_absx = fabsf(x_tmp);
    }

    if (b_absx <= 45.0F) {
      x_tmp *= 0.0174532924F;
      n = 0;
    } else if (b_absx <= 135.0F) {
      if (x_tmp > 0.0F) {
        x_tmp = (x_tmp - 90.0F) * 0.0174532924F;
        n = 1;
      } else {
        x_tmp = (x_tmp + 90.0F) * 0.0174532924F;
        n = -1;
      }
    } else if (x_tmp > 0.0F) {
      x_tmp = (x_tmp - 180.0F) * 0.0174532924F;
      n = 2;
    } else {
      x_tmp = (x_tmp + 180.0F) * 0.0174532924F;
      n = -2;
    }

    switch (n) {
     case 0:
      b_absx = sinf(x_tmp);
      break;

     case 1:
      b_absx = cosf(x_tmp);
      break;

     case -1:
      b_absx = -cosf(x_tmp);
      break;

     default:
      b_absx = -sinf(x_tmp);
      break;
    }
  }

  b_absx = 24.0F * x + 0.0F * b_absx;

  /* MATLAB Function: '<S3>/MATLAB Function1' incorporates:
   *  MATLAB Function: '<S3>/MATLAB Function2'
   */
  x = -openloop_Y.Va * 0.5F;

  /* Outport: '<Root>/Vb' incorporates:
   *  MATLAB Function: '<S3>/MATLAB Function1'
   */
  openloop_Y.Vb = b_absx * 0.866025388F + x;

  /* Outport: '<Root>/Vc' incorporates:
   *  MATLAB Function: '<S3>/MATLAB Function2'
   */
  openloop_Y.Vc = x - b_absx * 0.866025388F;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  openloop_M->Timing.t[0] =
    ((time_T)(++openloop_M->Timing.clockTick0)) * openloop_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.0032s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.0032, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    openloop_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void openloop_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&openloop_M->solverInfo,
                          &openloop_M->Timing.simTimeStep);
    rtsiSetTPtr(&openloop_M->solverInfo, &rtmGetTPtr(openloop_M));
    rtsiSetStepSizePtr(&openloop_M->solverInfo, &openloop_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&openloop_M->solverInfo, (&rtmGetErrorStatus
      (openloop_M)));
    rtsiSetRTModelPtr(&openloop_M->solverInfo, openloop_M);
  }

  rtsiSetSimTimeStep(&openloop_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&openloop_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(openloop_M, &openloop_M->Timing.tArray[0]);
  openloop_M->Timing.stepSize0 = 0.0032;
}

/* Model terminate function */
void openloop_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
