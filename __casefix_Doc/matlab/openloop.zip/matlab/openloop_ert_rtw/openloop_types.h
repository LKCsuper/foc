/*
 * File: openloop_types.h
 *
 * Code generated for Simulink model 'openloop'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Thu Aug 31 16:59:18 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_openloop_types_h_
#define RTW_HEADER_openloop_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_openloop_T RT_MODEL_openloop_T;

#endif                                 /* RTW_HEADER_openloop_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
