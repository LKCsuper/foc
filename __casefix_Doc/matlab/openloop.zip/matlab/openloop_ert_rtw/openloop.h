/*
 * File: openloop.h
 *
 * Code generated for Simulink model 'openloop'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Thu Aug 31 16:59:18 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_openloop_h_
#define RTW_HEADER_openloop_h_
#ifndef openloop_COMMON_INCLUDES_
#define openloop_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* openloop_COMMON_INCLUDES_ */

#include "openloop_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Constant parameters (default storage) */
typedef struct {
  /* Expression: rep_seq_y
   * Referenced by: '<S1>/Look-Up Table1'
   */
  real_T LookUpTable1_tableData[2];

  /* Expression: rep_seq_t - min(rep_seq_t)
   * Referenced by: '<S1>/Look-Up Table1'
   */
  real_T LookUpTable1_bp01Data[2];
} ConstP_openloop_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real32_T Va;                         /* '<Root>/Va' */
  real32_T Vb;                         /* '<Root>/Vb' */
  real32_T Vc;                         /* '<Root>/Vc' */
} ExtY_openloop_T;

/* Real-time Model Data Structure */
struct tag_RTM_openloop_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_openloop_T openloop_Y;

/* Constant parameters (default storage) */
extern const ConstP_openloop_T openloop_ConstP;

/* Model entry point functions */
extern void openloop_initialize(void);
extern void openloop_step(void);
extern void openloop_terminate(void);

/* Real-time Model object */
extern RT_MODEL_openloop_T *const openloop_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<Root>/Rate Transition2' : Eliminated since input and output rates are identical
 * Block '<S1>/Output' : Eliminate redundant signal conversion block
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'openloop'
 * '<S1>'   : 'openloop/Theta'
 * '<S2>'   : 'openloop/rePark1'
 * '<S3>'   : 'openloop/reclarke1'
 * '<S4>'   : 'openloop/rePark1/MATLAB Function'
 * '<S5>'   : 'openloop/rePark1/MATLAB Function1'
 * '<S6>'   : 'openloop/reclarke1/MATLAB Function'
 * '<S7>'   : 'openloop/reclarke1/MATLAB Function1'
 * '<S8>'   : 'openloop/reclarke1/MATLAB Function2'
 */
#endif                                 /* RTW_HEADER_openloop_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
